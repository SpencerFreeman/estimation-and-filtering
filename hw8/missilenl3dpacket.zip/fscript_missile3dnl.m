function [fscript,dfscript_dx,dfscript_dvtil] = ...
                           fscript_missile3dnl(t,x,u,vtil,idervflag)
%
%  Copyright (c) 2020 Mark L. Psiaki.  All rights reserved.  
%
% 
%  This function is for use in solving the 3-dimensional
%  missile tracking problem  It models the dynamics of a
%  missile's ballistic trajectory given in local-level
%  Vertical/East/North coordinates referenced to the U.S.
%  Naval Air Facility in Atsugi Japan, which is where the
%  tracking radar is assumed to be located.  It models
%  the Earth's gravity due to the 1/r^2 main term and the
%  J2 term.  It also models the Coriolis and centrifugal
%  terms that are caused by the Earth's rotation.
%
%
%  Inputs:
%
%    t               The time at which xdot is to be known.
%
%    x               = [rven;vven], the 6-by-1 missile state vector 
%                    at time t.  rven is the 3-by-1 position vector
%                    given in the local Vertical/East/North Cartesian
%                    coordinate frame whose origin is at the radar 
%                    location in Atsugi Japan. It is given in meters 
%                    units.  vven is the 3-by-1 velocity vector given 
%                    in the same local Vertical/East/North coordinate
%                    frame.  It is given in meters/sec units.
%
%    u               The 3x1 control vector at time t.  It is the
%                    missile acceleration caused by thrust and
%                    given in ECEF coordinates.  It is given
%                    in meters/sec^2 units.
%
%    vtil            The 3x1 process noise disturbance vector at time t.
%                    It is the missile acceleration due to random
%                    disturbances and given in ECEF coordinates.
%                    It is given in meters/sec^2 units.
%
%    idervflag       A flag that tells whether (idervflag = 1) or not
%                    (idervflag = 0) the partial derivatives 
%                    dfscript_dx and dfscript_dvtil must be calculated.
%                    If idervflag = 0, then these outputs will be
%                    empty arrays.
%  
%  Outputs:
%
%    fscript         The 6-by-1 time derivative of x at time t as 
%                    determined by the differential equation.
%                    fscript(1:3,1) is given in meters/sec units.
%                    fscript(4:6,1) is given in meters/sec^2 units.
%
%    dfscript_dx     The 6-by-6 partial derivative of fscript with 
%                    respect to x.  This is a Jacobian matrix.  It is 
%                    evaluated and output only if idervflag = 1.  
%                    Otherwise, an empty array is output.  The
%                    units of dfscript_dx(ii,jj) equal the units of
%                    fscript(ii,1) divided by the units of x(jj,1).
%
%    dfscript_dvtil  The 6-by-3 partial derivative of fscript with 
%                    respect to vtil.  This is a Jacobian matrix.  
%                    It is evaluated and output only if idervflag = 1.  
%                    Otherwise, an empty array is output.  The
%                    units of dfscript_dvtil(ii,jj) equal the units of
%                    fscript(ii,1) divided by the units of vtil(jj,1).
%

%
%  Extract the position and velocity vectors in the local-level
%  Vertical/East/North coordinates that are defined at the
%  U.S. Naval Air Facility in Atsugi, Japan.
%
   rven = x(1:3,1);
   vven = x(4:6,1);
%
%  Set up the the WGS-84 ECEF Cartesian position vector of the
%  local-level coordinate system origin at the U.S. Naval Air 
%  Facility in Atsugi, Japan.  It is given in meters units.
%  This vector has been taken from the file coordinatessetup.mat.
%
   rECEF_atsugi = 1.0e+06*[-3.952262886675294;...
                            3.381521064117842;...
                            3.678906121242383];
%
%  Set up the coordinate transformation matrix for the rotation
%  from WGS-84 ECEF Cartesian axes to local-level Vertical/East/North
%  Cartesian axes at the U.S. Naval Air Facility in Atsugi, Japan.
%  This matrix has been taken from the file coordinatessetup.mat.
%
   Avenatsugi_ECEF = ...
     [-0.618959682352019   0.529576413241511   0.580032528536930;...
      -0.650111417180096  -0.759838894274364                   0;...
       0.440731275126664  -0.377085769137698   0.814593313156360];
%
%  Compute the missile position and velocity in WGS-84 ECEF coordinates.
%
   AECEF_venatsugi = Avenatsugi_ECEF';
   rECEF = rECEF_atsugi + AECEF_venatsugi*rven;
   vECEF = AECEF_venatsugi*vven;
%
%  Compute the gravitational acceleration.
%
   [gECEF,dgECEF_drECEF] = gaccecef_oneoverrsqandj2(rECEF,idervflag);
%
%  Compute the Coriolis and centrifugal acceleration terms.
%
   omegaEarthECEF = [0;0;7.2921151467e-05];
   omegaEarthECEF_cpeq = ...
            [0,(-omegaEarthECEF(3,1)),omegaEarthECEF(2,1);...
             omegaEarthECEF(3,1),0,(-omegaEarthECEF(1,1));...
             (-omegaEarthECEF(2,1)),omegaEarthECEF(1,1),0];
   twoomegaEarthECEF_cpeq = 2*omegaEarthECEF_cpeq;
   omegaEarthECEF_cpeqsq = omegaEarthECEF_cpeq*omegaEarthECEF_cpeq;         
   acoripluscentr = twoomegaEarthECEF_cpeq*vECEF + ...
                      omegaEarthECEF_cpeqsq*rECEF;
%
%  Compute the missile's total acceleration relative to ECEF coordinates.
%  
   aECEF = gECEF - acoripluscentr + u + vtil;
%
%  Transform the acceleration vector back into local-level
%  Vertical/East/North coordinates at the
%  U.S. Naval Air Facility in Atsugi, Japan.
%
   aven = Avenatsugi_ECEF*aECEF;
%
%  Assign the outputs of fscript.
%
   fscript = [vven;aven];
%
%  Do the derivative calculations if called for.
%
   if idervflag == 1
      dfscript_dx = zeros(6,6);
%
      dfscript_dx(1:3,4:6) = eye(3);
%      
      dacoripluscentr_drECEF = omegaEarthECEF_cpeqsq;
      daECEF_drECEF = dgECEF_drECEF - dacoripluscentr_drECEF;
      drECEF_drven = AECEF_venatsugi;
      daECEF_drven = daECEF_drECEF*drECEF_drven;
      daven_daECEF = Avenatsugi_ECEF;
      daven_drven = daven_daECEF*daECEF_drven;
      dfscript_dx(4:6,1:3) = daven_drven;
%      
      dacoripluscentr_dvECEF = twoomegaEarthECEF_cpeq;
      daECEF_dvECEF = - dacoripluscentr_dvECEF;
      dvECEF_dvven = AECEF_venatsugi;
      daECEF_dvven = daECEF_dvECEF*dvECEF_dvven;
      daven_dvven = daven_daECEF*daECEF_dvven;
      dfscript_dx(4:6,4:6) = daven_dvven;
%      
      dfscript_dvtil = zeros(6,3);
      daECEF_dvtil = eye(3);
      daven_dvtil = daven_daECEF*daECEF_dvtil;
      dfscript_dvtil(4:6,:) = daven_dvtil;
   else
      dfscript_dx = [];
      dfscript_dvtil = [];
   end