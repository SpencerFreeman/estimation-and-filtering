function [h,H] = hjmissile3dnl(t,x,i1stdrv)
%
%  Copyright (c) 2020 Mark L. Psiaki.  All rights reserved.  
% 
%  This function computes the measurement function h(t,x) and its 
%  first derivative with respect to x, H = dh/dx. It is for use in 
%  the 3-dimensional batch nonlinear least-squares estimation
%  problem that does missile tracking.  The measurements are range, 
%  elevation angle, and azimuth angle as measured at a radar located 
%  at the origin of the problem's Cartesian coordinate system.
%
%  This version allows for a general Earth gravity field model, 
%  Coriolis and centrifugal accelerations due to the Earth's
%  rotation, aerodynamic drag force, and other disturbances 
%  that may act on the missile.  The initial implementation
%  of this problem includes only the Earth's 1/r^2 and
%  J2 gravity terms along with Coriolis and centrifugal
%  accelerations due to the Earth's rotation.  It does not
%  include atmospheric drag, though the present measurement
%  model function is agnostic to the choice of which particular 
%  terms are included in its dynamic model because this
%  measurement model function considers only the current
%  position/velocity state of the missile.
%  
%
%  Inputs:
%
%    t        The time in seconds of the radar measurement.
%
%    x        = [rven;vven], the 6-by-1 missile state vector 
%             at time t.  rven is the 3-by-1 position vector
%             given in the local Vertical/East/North Cartesian
%             coordinate frame whose origin is at the radar location.   
%             It is given in meters units.  vven is the 3-by-1 velocity
%             vector given in the local Vertical/East/North coordinate
%             frame.  It is given in meters/sec units.  
%
%    i1stdrv  A flag that tells whether (i1stdrv = 1) or not 
%             (i1stdrv = 0) H needs to get computed.
%  
%  Outputs:
%
%    h        = [rho;theta;psi], the 3x1 radar output vector.  rho
%             is the measured distance from the radar to the missile
%             at time t given in meters.  theta is the measured
%             elevation angle of the missile above the local horizon
%             as measured by the radar, in radians.  psi is the measured
%             azimuth angle of the missile relative to local north
%             as measured by the radar, in radians.  psi = 0 radians
%             indicates that the missile is due north, 
%             psi = pi/2 radians indicates that the missile is due
%             east, psi = pi radians indicates that the missile 
%             due south, and psi = -pi/2 radians indicates that the
%             missile is due west.
%
%    H        = dh/dx.  H is a 3x6 matrix H(1,i) is the derivative
%             of rho with respect to x(i).  H(2,i) is the derivative
%             of theta with respect to x(i).  H(3,i) is the derivative
%             of psi with respect to x(i).  This output will
%             be needed to do Gauss-Newton estimation.
%             The units of H(1,1:3) are non-dimensional.  
%             The units of H(1,4:6) are seconds.  
%             The units of H(2:3,1:3) are radians/meter.  
%             The units of H(2:3,4:6) are radian-seconds/meter.  
%

%
%  Set up the first derivative output array as needed.
%
   if i1stdrv == 1
      H = zeros(3,6);
   else
      H = [];
   end
%
%  Compute the range to the missile
%
   rhosq = sum(x(1:3,1).^2);
   rho = sqrt(rhosq);
%
%  Compute the elevation angle of the missile
%
   oorho = 1/rho;
   sintheta = x(1,1)*oorho;
   theta = asin(sintheta);
%
%  Compute the azimuth angle of the missile
%
   Xne = x(3,1);
   Yne = x(2,1);
   psi = atan2(Yne,Xne);
%
%  Construct the measured output vector.
%
   h = [rho;theta;psi];
%
%  Return if the first derivatives do not need to be calculated.
%
   if i1stdrv == 0
      return
   end
%
%  Calculate the first derivatives.  Use analytic formulas.
%
   drhosq_dx = [(2*(x(1:3,1))'),zeros(1,3)];
   halforho = 0.5*oorho;
   drho_dx = halforho*drhosq_dx;
   H(1,:) = drho_dx;
%
   negoneorhos2 = - (oorho^2);
   doorho_dx = negoneorhos2*drho_dx;
   dsintheta_dx = [oorho,zeros(1,5)] + x(1,1)*doorho_dx;
   costhetasq = 1 - sintheta^2;
   costhetasq = max([costhetasq;0]);
   costheta = sqrt(costhetasq);
   oocostheta = 1/costheta;
   dtheta_dx = oocostheta*dsintheta_dx;
   H(2,:) = dtheta_dx;
%
   dXne_dx = [0,0,1,0,0,0];
   dYne_dx = [0,1,0,0,0,0];
   XnesqpYnesq = Xne^2 + Yne^2;
   ooXnesqpYnesq = 1/XnesqpYnesq;
   dpsi_dx = ooXnesqpYnesq*(- Yne*dXne_dx + Xne*dYne_dx);
   H(3,:) = dpsi_dx;