function [J,delx0gn,dJdalpha,d2Jdalpha2,P,dJdx0] = ...
                 jdxgnmissile3dnl(t0,x0guess,tmeashist,zhist,...
                                  sigmazhist,idelx,deltRKmax)
%
%  Copyright (c) 2020 Mark L. Psiaki.  All rights reserved.  
% 
%  This function is for a radar missile tracking problem.  
%  It computes the cost, the Gauss-Newton step, the
%  first and (approximate) second derivatives of the cost with respect
%  to the step size, alpha, the approximate estimation error
%  covariance matrix (assuming that the optimal solution
%  has been reached for the nonlinear least-squares problem), and
%  the first derivative of the cost with respect to x0.
%
%  These calculations apply to a 3-dimensional nonlinear
%  missile tracking problem that uses radar range, elevation,
%  and azimuth measurements from a single radar that is located
%  at the origin of the Vertical/East/North local-level coordinate 
%  system in which the state of the missile is defined.
%  
%
%  Inputs:
%
%    t0           The time in seconds at which the initial
%                 missile position/velocity state in x0guess
%                 applies.
%
%    x0guess      = [rven0guess;vven0guess], the 6-by-1 guess of
%                 the initial missile state vector at time t0.  
%                 rven0guess is the 3-by-1 position vector given in 
%                 the local Vertical/East/North Cartesian coordinate 
%                 frame whose origin is at the radar location.  It is 
%                 given in meters units.  vven0guess is the 3-by-1 
%                 velocity vector given in the same local Vertical/
%                 East/North coordinate frame.  It is given in 
%                 meters/sec units.
%
%    tmeashist    The Nmeas-by-1 vector of times at which the radar
%                 measured range, elevation, and azimuth.  These times 
%                 are given in seconds measured from the same time 
%                 datum as t0.  They apply to the measurements in
%                 zhist.
%
%                 Note: the vector of times [t0;tmeashist] must be
%                 monotonically increasing.
%
%    zhist        The (3*Nmeas)-by-1 vector that contains the 
%                 range measurements, elevation measurements, and
%                 azimuth measurements.  rhohist = zhist(1:3:...
%                 ((3*Nmeas)-2),1) is the vector of range measurements 
%                 at the times in tmeashist given in units of meters.
%                 thetahist = zhist(2:3:((3*Nmeas)-1),1) is the vector 
%                 of elevation measurements at the times in tmeashist 
%                 given in units of radians.  psihist = hbatch(3:3:...
%                 (3*Nmeas),1) is the vector of azimuth measurements 
%                 at the times in tmeashist given in units of radians.
%                 Each element of thetahist is the measured elevation 
%                 angle of the missile above the local horizon of the
%                 radar, in radians.  Each element of psihist is the 
%                 measured azimuth angle of the missile relative to 
%                 local north of the radar.  psi = 0 radians indicates 
%                 that the missile is due north of the radar, psi = pi/2  
%                 radians indicates that the missile is due east of the
%                 radar, psi = pi radians indicates that the missile 
%                 due south of the radar, and psi = -pi/2 radians 
%                 indicates that the missile is due west of the radar.
%
%    sigmazhist   The (3*Nmeas)-by-1 vector that contains the 
%                 measurement error standard deviations of the range 
%                 measurements, elevation measurements, and azimuth 
%                 measurements.  sigmarhohist = sigmazhist(1:3:...
%                 ((3*Nmeas)-2),1) is the vector of range measurement 
%                 error standard deviations, in meters, for the 
%                 corresponding range measurements in 
%                 rhohist = zhist(1:3:((3*Nmeas)-2),1).
%                 sigmathetahist = sigmazhist(2:3:((3*Nmeas)-1),1) is 
%                 the vector of elevation measurement error standard 
%                 deviations, in radians, for the corresponding elevation 
%                 measurements in thetahist = zhist(2:3:((3*Nmeas)-1),1).
%                 sigmapsihist = sigmazhist(1:3:(3*Nmeas),1) is 
%                 the vector of azimuth measurement error standard 
%                 deviations, in radians, for the corresponding azimuth 
%                 measurements in psihist = zhist(1:3:(3*Nmeas),1).
%                 This function assumes that all of the various 
%                 random measurement errors are uncorrelated.
%
%    idelx        A flag that tells whether (idelx == 1) or not
%                 (idelx == 0) to compute the other outputs besides J.
%
%    deltRKmax    The maximum 4th-order Runge-Kutta numerical
%                 integration interval to use when integrating
%                 the state dynamics system of nonlinear ODEs 
%                 between adjacent times in [t0;tmeashist], 
%                 in seconds.
%  
%  Outputs:
%
%    J            The nonlinear least-squares cost.  Note that this
%                 is divided by 2 compared to the cost given in
%                 Bar-Shalom.
%
%    delx0gn      The Gauss-Newton perturbation to x0guess that is
%                 supposed to yield the optimal x0.
%
%    dJdalpha     = dJ(x0guess+alpha*delx0gn)/dalpha evaluated at
%                 alpha = 0.
%
%    d2Jdalpha2   = d2J(x0guess+alpha*delx0gn)/dalpha2 evaluated at
%                 alpha = 0, except that the Hessian matrix d2Jdx02 
%                 used in this calculation is only the Gauss-Newton 
%                 approximation of the cost function Hessian.
%
%    P            The 6x6 Gauss-Newton approximation of the estimation
%                 error covariance.  It is the inverse of the approximate
%                 Hessian of J.
%
%    dJdx0        The 6x1 first partial derivative of J with respect
%                 to x0.  dJdx0(i,1) = dJ/dx0(i).
%

%
%  Call the measurement model function.
%
   [hbatch,Hbatch] = ...
                 hbatchmissile3dnl(t0,x0guess,tmeashist,deltRKmax,idelx);
%
%  Compute the vector of normalized residual measurement errors.
%
   oosigmazhist = sigmazhist.^(-1);
   deltazavec = (zhist - hbatch).*oosigmazhist;
%
%  Compute the cost.
%
   J = 0.5*(deltazavec'*deltazavec);
%
%  Return if only the cost is needed.
%
   if idelx == 0
      delx0gn = [];
      dJdalpha = [];
      d2Jdalpha2 = [];
      P = [];
      dJdx0 = [];
      return
   end
%
%  Compute the Gauss-Newton search direction.  Use QR factorization.
%
   Ha = Hbatch.*(oosigmazhist*ones(1,6));
   [Qb,Rb] = qr(Ha,0);
   delzb1vec = (Qb')*deltazavec;
   Rbinv = inv(Rb);
   delx0gn = Rbinv*delzb1vec;
   P = Rbinv*(Rbinv');
   dJdx0 = - (Ha')*deltazavec;
   dJdalpha = (dJdx0')*delx0gn;
   dum = Rb*delx0gn;
   d2Jdalpha2 = (dum')*dum;