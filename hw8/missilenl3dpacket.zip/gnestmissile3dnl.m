function [x0est,Jopt,P,itermflag] = ...
                 gnestmissile3dnl(t0,x0guess,tmeashist,zhist,...
                                  sigmazhist,deltRKmax,idispflag)
%
%  Copyright (c) 2020 Mark L. Psiaki.  All rights reserved.  
% 
%  This function does Gauss-Newton estimation of the initial
%  state of a missle in a missle tracking problem.  This
%  particular version of the problem is for 3D missile motion
%  with radar tracking of range, elevation, and azimuth
%  to the missile and with the ballistic missile dynamics
%  model including the 1/r^2 gravity term, the J2 Earth
%  oblateness gravity term, and the Coriolis and
%  centrifugal effects of the Earth's rotation.
%  Almost all calculations are done in the local-level
%  Vertical/East/North Cartesian coordinate system that
%  is centered at the radar.
%  
%
%  Inputs:
%
%    t0           The time in seconds at which the initial
%                 missile position/velocity state in x0guess
%                 applies and at which the optimal estimate
%                 of the state in x0est will apply.
%
%    x0guess      = [rven0guess;vven0guess], the 6-by-1 initial guess 
%                 of the initial missile state vector at time t0.  
%                 rven0guess is the 3-by-1 position vector given in 
%                 the local Vertical/East/North Cartesian coordinate 
%                 frame whose origin is at the radar location.  It is 
%                 given in meters units.  vven0guess is the 3-by-1 
%                 velocity vector given in the same local Vertical/
%                 East/North coordinate frame.  It is given in 
%                 meters/sec units.
%
%    tmeashist    The Nmeas-by-1 vector of times at which the radar
%                 measured range, elevation, and azimuth.  These times 
%                 are given in seconds measured from the same time 
%                 datum as t0.  They apply to the measurements in
%                 zhist.
%
%                 Note: the vector of times [t0;tmeashist] must be
%                 monotonically increasing.
%
%    zhist        The (3*Nmeas)-by-1 vector that contains the 
%                 range measurements, elevation measurements, and
%                 azimuth measurements.  rhohist = zhist(1:3:...
%                 ((3*Nmeas)-2),1) is the vector of range measurements 
%                 at the times in tmeashist given in units of meters.
%                 thetahist = zhist(2:3:((3*Nmeas)-1),1) is the vector 
%                 of elevation measurements at the times in tmeashist 
%                 given in units of radians.  psihist = hbatch(3:3:...
%                 (3*Nmeas),1) is the vector of azimuth measurements 
%                 at the times in tmeashist given in units of radians.
%                 Each element of thetahist is the measured elevation 
%                 angle of the missile above the local horizon of the
%                 radar, in radians.  Each element of psihist is the 
%                 measured azimuth angle of the missile relative to 
%                 local north of the radar.  psi = 0 radians indicates 
%                 that the missile is due north of the radar, psi = pi/2  
%                 radians indicates that the missile is due east of the
%                 radar, psi = pi radians indicates that the missile 
%                 due south of the radar, and psi = -pi/2 radians 
%                 indicates that the missile is due west of the radar.
%
%    sigmazhist   The (3*Nmeas)-by-1 vector that contains the 
%                 measurement error standard deviations of the range 
%                 measurements, elevation measurements, and azimuth 
%                 measurements.  sigmarhohist = sigmazhist(1:3:...
%                 ((3*Nmeas)-2),1) is the vector of range measurement 
%                 error standard deviations, in meters, for the 
%                 corresponding range measurements in 
%                 rhohist = zhist(1:3:((3*Nmeas)-2),1).
%                 sigmathetahist = sigmazhist(2:3:((3*Nmeas)-1),1) is 
%                 the vector of elevation measurement error standard 
%                 deviations, in radians, for the corresponding elevation 
%                 measurements in thetahist = zhist(2:3:((3*Nmeas)-1),1).
%                 sigmapsihist = sigmazhist(1:3:(3*Nmeas),1) is 
%                 the vector of azimuth measurement error standard 
%                 deviations, in radians, for the corresponding azimuth 
%                 measurements in psihist = zhist(1:3:(3*Nmeas),1).
%                 This function assumes that all of the various 
%                 random measurement errors are uncorrelated.
%
%    deltRKmax    The maximum 4th-order Runge-Kutta numerical
%                 integration interval to use when integrating
%                 the state dynamics system of nonlinear ODEs 
%                 between adjacent times in [t0;tmeashist], 
%                 in seconds.
%
%    idispflag    A flag that tells whether (idispflag = 1) or not 
%                 (idispflag = 0) to display interm optimization
%                 results during the Gauss-Newton iterations.
%  
%  Outputs:
%
%    x0est        = [rven0est;vven0est], the 6-by-1 final estimate 
%                 of the initial missile state vector at time t0.  
%                 rven0est is the 3-by-1 position vector given in 
%                 the local Vertical/East/North Cartesian coordinate 
%                 frame whose origin is at the radar location.  It is 
%                 given in meters units.  vven0est is the 3-by-1 
%                 velocity vector given in the same local Vertical/
%                 East/North coordinate frame.  It is given in 
%                 meters/sec units.
%
%    Jopt         The final optimal value of the nonlinear least-squares
%                 cost.  Note that this is divided by 2 compared to the  
%                 cost given in Bar-Shalom.
%
%    P            The 6x6 Gauss-Newton approximation of the estimation
%                 error covariance for the error in x0est.  It is the 
%                 inverse of the approximate Hessian of J.
%
%    itermflag    A termination flag that tells whether the
%                 procedure terminated well or not.  Its output values
%                 have the following interpretations:
%
%                   0   Normal termination at the optimum
%
%                   1   Terminated because more than 25 step
%                       size halvings were required.  This
%                       may be an optimum.
%
%                   2   Terminated because more than 100
%                       Gauss-Newton iterations were required.
%                       This probably is not the optimum.
%

%
%  Calculate the initial cost and the initial Gauss-Newton search
%  direction.
%
   x0est = x0guess;
   [Jopt,delx0gn,dJdalpha,d2Jdalpha2,P] = ...
                 jdxgnmissile3dnl(t0,x0est,tmeashist,zhist,...
                                  sigmazhist,1,deltRKmax);
%
%  Predict the change in cost if a step size of alpha = 1 is taken.
%
   delJpred = dJdalpha + .5*d2Jdalpha2;
%
%  Decide whether to terminate now.
%
   delJsizetest = abs(delJpred) < 1.e-13*(1 + Jopt);
   delxsizetest = norm(delx0gn) < 1.e-09*(1 + norm(x0est));
   itermflag = 0;
   if delJsizetest & delxsizetest
      return
   end
%
%  Prepare some quantities for use in controlling the Gauss-Newton
%  iterations.
%
   testdone = 0;
   niteration = 0;
   iaflag = 0;
%
%  Do one Gauss-Newton iteration per iteration of the following while
%  loop.
%
   while testdone == 0
      alpha = 1;
      x0estnew = x0est + alpha*delx0gn;
      Jnew = jdxgnmissile3dnl(t0,x0estnew,tmeashist,zhist,...
                              sigmazhist,0,deltRKmax);
%
%  Do step size halving if necessary in order to force a decrease
%  in the cost.
%
      nalphahalf = 0;
      while Jnew >= Jopt
         nalphahalf = nalphahalf + 1;
         if nalphahalf > 25
            iaflag = 1;
            break
         end
         alpha = 0.5*alpha;
         x0estnew = x0est + alpha*delx0gn;
         Jnew = jdxgnmissile3dnl(t0,x0estnew,tmeashist,zhist,...
                                 sigmazhist,0,deltRKmax);
      end
      if iaflag == 1
         itermflag = 1;
         break
      end
      x0est = x0estnew;
      Jold = Jopt;
      delJold = Jnew - Jopt;
      delJpredold = delJpred;
      [Jopt,delx0gn,dJdalpha,d2Jdalpha2,P] = ...
                 jdxgnmissile3dnl(t0,x0est,tmeashist,zhist,...
                                  sigmazhist,1,deltRKmax);
      delJpred = dJdalpha + .5*d2Jdalpha2;
      delJsizetest = abs(delJpred) < 1.e-13*(1 + Jopt);
      delxsizetest = norm(delx0gn) < 1.e-09*(1 + norm(x0est));
      alphatest = alpha == 1;
      delJratiotest = abs((delJold/delJpredold) - 1) < 0.025;
      if delJsizetest & delxsizetest
         testdone = 1;
      end
      if alphatest & delJratiotest & delxsizetest
         testdone = 1;
      end
      niteration = niteration + 1;                
      if testdone == 0
         if niteration >= 100
            itermflag = 2;
            testdone = 1;
         end
      end
      if idispflag == 1
         disp([' At iteration ',int2str(niteration),' alpha = ',...
                num2str(alpha),', Jnew = ',num2str(Jopt),', Jold = ',...
                num2str(Jold),', and norm(delx0new) = ',...
                num2str(norm(delx0gn)),'.'])
      end
   end  