function [gECEF,dgECEF_drECEF] = gaccecef_oneoverrsqandj2(rECEF,dervflag)
%
%  Copyright (c) 2017, 2020 Mark L. Psiaki.  All rights reserved.  
%
%  This function computes the gravitational acceleration in ECEF (Earth-
%  Centered, Earth-Fixed) coordinates that occurs due to the 
%  Earth's gravity.  It only includes the 1/r^2 term and the J2 term.  
%  This calculation technically occurs in ECEF (Earth-Centered/
%  Earth-Fixed) coordinates -- these coordinates rotate with the 
%  Earth.  Its inputs and outputs, however, also can be deemed to be 
%  given in ECI (Earth-Centered/Inertial) coordinates -- 
%  these latter coordinates do not rotate with respect to inertial
%  space.  This is true because the 1/r^2 gravity term and
%  the J2 term are both axially symmetric about the Earth's 
%  rotation axis.
%
%  An additional output of this function is the gravity gradient,
%  dgECEF_drECEF.  It gets computed only if dervflag = 1.
%
%  Inputs:
%
%     rECEF          The 3x1 spacecraft position vector in the ECEF frame
%                    (meters).
%
%     dervflag       A flag that tells whether (dervflag == 1) or not
%                    (dervflag == 0) to compute the gravity gradient matrix
%                    dgECEF_drECEF.  If dervflag == 0, then dgECEF_drECEF
%                    will be an empty array on output.
%
%  Outputs:
%
%     gECEF          The net 3x1 ECEF gravitational acceleration vector in 
%                    the ECEF frame that is caused by the Earth (1/r^2 
%                    term and J2 term only), in m/sec^2.
%
%     dgECEF_drECEF  The 3x3 Jacobian first partial derivative of gECEF 
%                    with respect to rECEF, in 1/sec^2 units.  This
%                    will be an empty array on output if dervflag == 0 
%                    on input.
%
%
%

%
%  Define three constants of the gravity model:
%
   a_earth = 6378136.3 ;          % Earth's mean equatorial radius in m
   mu_earth = 3986004.415e+08;    % m^3/sec^2
   J2 = 0.001082626683553114;     % non-dimensional
%
%  Compute the 1/r^2 term of the gravitational acceleration
%
   rECEFmagsq = sum(rECEF.^2);
   oneoverrECEFmagsq = 1/rECEFmagsq;
   oneoverrECEFmagsqto1p5 = oneoverrECEFmagsq^(1.5);
   mu_earthoverrECEFmagsqto1p5 = mu_earth*oneoverrECEFmagsqto1p5;
   gECEFoneoverrsq = - mu_earthoverrECEFmagsqto1p5*rECEF;
%
%  Compute the J2 term of the gravitational acceleration.
%
   a_earthsq = a_earth^2;
   a_earthsqoverrECEFmagsq = a_earthsq*oneoverrECEFmagsq;
   Zsq = rECEF(3,1)^2;
   ZsqoverrECEFmagsq = Zsq*oneoverrECEFmagsq;
   neg7p5ZsqoverrECEFmagsq = - 7.5*ZsqoverrECEFmagsq;
   matrixfactor = diag([1.5;1.5;4.5]) + neg7p5ZsqoverrECEFmagsq*eye(3);
   matrixfactor_rECEF = matrixfactor*rECEF;
   scalarJ2factor = ...
         - J2*mu_earthoverrECEFmagsqto1p5*a_earthsqoverrECEFmagsq;
   gECEFJ2 = matrixfactor_rECEF*scalarJ2factor;
%
%  Sum the two gravity terms to get the total gravitational 
%  acceleration in this model.
%
   gECEF = gECEFoneoverrsq + gECEFJ2;
%
%  Compute the Jacobian first partial derivative of gECEF with 
%  respect to rECEF if output of this quantity is called for
%  by the input value of dervflag.
%
   if dervflag == 1
%
%  Compute the Jacobian first partial derivative of the 1/r^2 term 
%  using a formula from lecture.
%
      dgECEFoneoverrsq_drECEF = ...
          - mu_earthoverrECEFmagsqto1p5*...
              (eye(3) - (3*oneoverrECEFmagsq)*rECEF*(rECEF'));
%
%  Compute the Jacobian first partial derivative of the J2 term 
%  by successively differentiating all of the terms that lead
%  up to the computation of this term.  Use various well-known
%  rules of scalar and vector calculus in order to accomplish this.
%
%  Note that the Jacobian first partial derivative of a scalar
%  with respect to a 3-by-1 column vector is defined to be
%  a 1-by-3 row vector.  Also, the derivative of a 3-by-1
%  column vector with respect to another 3-by-1 column vector
%  is defined to be a 3-by-3 Jacobian matrix.
%
      drECEFmagsq_drECEF = 2*(rECEF');
      negoneoverrECEFmagsqsq = - (oneoverrECEFmagsq^2);
      doneoverrECEFmagsq_drECEF = ...
              negoneoverrECEFmagsqsq*drECEFmagsq_drECEF;
      da_earthsqoverrECEFmagsq_drECEF = ...
              a_earthsq*doneoverrECEFmagsq_drECEF;
      dZsq_drECEF = [0,0,(2*rECEF(3,1))];
      dZsqoverrECEFmagsq_drECEF = dZsq_drECEF*oneoverrECEFmagsq + ...
                                  Zsq*doneoverrECEFmagsq_drECEF;
      dneg7p5ZsqoverrECEFmagsq_drECEF = - 7.5*dZsqoverrECEFmagsq_drECEF;
      dmatrixfactor_dX = dneg7p5ZsqoverrECEFmagsq_drECEF(1,1)*eye(3);
      dmatrixfactor_dY = dneg7p5ZsqoverrECEFmagsq_drECEF(1,2)*eye(3);
      dmatrixfactor_dZ = dneg7p5ZsqoverrECEFmagsq_drECEF(1,3)*eye(3);
      dmatrixfactor_rECEF_drECEF = ...
             [(dmatrixfactor_dX*rECEF),(dmatrixfactor_dY*rECEF),...
                          (dmatrixfactor_dZ*rECEF)] + ...
             matrixfactor;
      doneoverrECEFmagsqto1p5_drECEF = ...
             (1.5*(oneoverrECEFmagsq^(0.5)))*doneoverrECEFmagsq_drECEF;
      dmu_earthoverrECEFmagsqto1p5_drECEF = ...
             mu_earth*doneoverrECEFmagsqto1p5_drECEF;
      
      dscalarJ2factor_drECEF = ...
         - J2*(dmu_earthoverrECEFmagsqto1p5_drECEF*...
                      a_earthsqoverrECEFmagsq + ...
               mu_earthoverrECEFmagsqto1p5*...
                      da_earthsqoverrECEFmagsq_drECEF);
%
%  Note that the second term on the right-hand side of the
%  formula below cannot have its multiplication commuted
%  because the result would become a scalar rather than the
%  needed 3-by-3 matrix.
%
      dgECEFJ2_drECEF = dmatrixfactor_rECEF_drECEF*scalarJ2factor + ...
                        matrixfactor_rECEF*dscalarJ2factor_drECEF;
%
%  Add the Jacobian first partial derivatives of the two gravity
%  terms in order to yield the Jacobian first partial derivative
%  of the full gravity term.
%
      dgECEF_drECEF = dgECEFoneoverrsq_drECEF + dgECEFJ2_drECEF;
   else
      dgECEF_drECEF = [];
   end