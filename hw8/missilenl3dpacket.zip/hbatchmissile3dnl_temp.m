function [hbatch,Hbatch] = ...
                 hbatchmissile3dnl(t0,x0,tmeashist,deltRKmax,i1stdrv)
%
%  Copyright (c) 2020 Mark L. Psiaki.  All rights reserved.  
% 
%  This function computes the batch measurement function hbatch(t0,x0) 
%  and its first derivative with respect to x0, Hbatch = dhbatch/dx0. 
%  It is for use in the 3-dimensional batch nonlinear least-squares 
%  estimation problem that does missile tracking.  The measurements 
%  are range, elevation angle, and azimuth angle as measured at a 
%  radar located at the origin of the problem's Cartesian coordinate 
%  system.  This function models how a whole time history of
%  measurements depends on the initial position/velocity state of the
%  missile at time t0, x0, and on the measurement times in
%  tmeashist.  This function calls c2dnonlinear.m in order
%  to use Runge-Kutta numerical integration as a means of
%  dynamically propagating from time t0 to the measurement times in
%  tmeashist.  It then uses hjmissile3dnl.m in order to
%  model the range, elevation, and azimuth measurements at 
%  any given measurement time in tmeashist.
%
%  The derivative calculations for this function
%  use the state transition matrix derivative calculations
%  in c2dnonlinear.m and the measurement derivative
%  calculations in hjmissile3dnl.m in order to compute
%  the derivatives of the measurements with respect
%  to the initial conditions in x0.  The individual
%  state transition matrices calculated by
%  c2dnonlinear.m for each transition from one 
%  measurement time to the next must be combined
%  in an appropriate manner in order to yield the
%  proper state transition matrix from time t0 to
%  any given measurement time in tmeashist.
%  
%
%  Inputs:
%
%    t0         The time in seconds at which the initial
%               missile position/velocity state in x0
%               applies.
%
%    x0         = [rven0;vven0], the 6-by-1 initial missile state vector 
%               at time t0.  rven0 is the 3-by-1 position vector given 
%               in the local Vertical/East/North Cartesian coordinate 
%               frame whose origin is at the radar location.  It is 
%               given in meters units.  vven0 is the 3-by-1 velocity
%               vector given in the same local Vertical/East/North
%               coordinate frame.  It is given in meters/sec units.  
%
%    tmeashist  The Nmeas-by-1 vector of times at which the radar
%               measured range, elevation, and azimuth.  These times 
%               are given in seconds measured from the same time 
%               datum as t0.
%
%               Note: the vector of times [t0;tmeashist] must be
%               monotonically increasing.
%
%    deltRKmax  The maximum 4th-order Runge-Kutta numerical
%               integration interval to use when integrating
%               the state dynamics system of nonlinear ODEs 
%               between adjacent times in [t0;tmeashist], 
%               in seconds.
%
%    i1stdrv    A flag that tells whether (i1stdrv == 1) or not 
%               (i1stdrv == 0) Hbatch needs to get computed.
%  
%  Outputs:
%
%    hbatch     The (3*Nmeas)-by-1 vector that contains the modeled
%               range measurements, elevation measurements, and
%               azimuth measurements.  rhohist = hbatch(1:3:...
%               ((3*Nmeas)-2),1) is the vector of modeled range 
%               measurements at the times in tmeashist given in units
%               of meters. thetahist = hbatch(2:3:((3*Nmeas)-1),1) is 
%               the vector of modeled elevation measurements at the 
%               times in tmeashist given in units of radians.  
%               psihist = hbatch(3:3:(3*Nmeas),1) is the vector  
%               of modeled azimuth measurements 
%               at the times in tmeashist given in units of radians.
%               Each element of thetahist is the measured elevation 
%               angle of the missile above the local horizon of the
%               radar, in radians.  Each element of psihist is the 
%               measured azimuth angle of the missile relative to 
%               local north of the radar.  psi = 0 radians indicates 
%               that the missile is due north of the radar, psi = pi/2  
%               radians indicates that the missile is due east of the
%               radar, psi = pi radians indicates that the missile 
%               due south of the radar, and psi = -pi/2 radians 
%               indicates that the missile is due west of the radar.
%
%    Hbatch     = dhbatch/dx0.  Hbatch is a (3*Nmeas)-by-6 matrix.
%               The units of Hbatch(ii,jj) equal the units of
%               hbatch(ii,1) divided by the units of x0(jj,1).
%               This array will be empty on output if i1stdrv == 0
%               on inputs.
%

%
%  Determine the number of measurements and check that the
%  times are monotonically increasing.
%
   Nmeas = size(tmeashist,1);
   dtvec = diff([t0;tmeashist]);
   if min(dtvec) <= 0
      error(['Error in hbatchmissile3dnl.m:',...
             ' min(diff([t0;tmeashist])) <= 0.'])
   end
%
%  Set up the output arrays.
%
   threeNmeas = 3*Nmeas;
   hbatch = zeros(threeNmeas,1);
   if i1stdrv == 1
      Hbatch = zeros(threeNmeas,6);
   else
      Hbatch = [];
   end
%
%  Perpare to call c2dnonlinear.m in order to dynamically
%  propagate the missile's state from t0 to the measurement
%  times.  Define the continuous-time ODE's nonlinear
%  function.
%
  fscriptname = @(targ,xarg,uarg,vtilarg,idervflagarg) ...
                 fscript_missile3dnl(targ,xarg,uarg,vtilarg,idervflagarg);
%
%  Set the thrust acceleration and the process noise acceleration
%  terms to zero.  The thrust acceleration is zero because this
%  function models the missile's motion during its ballistic
%  phase when its rocket engines have shut off.  Process noise
%  acceleration is zero because this measurement model is for use
%  as part of a batch nonlinear least-squares filter which assumes
%  that its dynamics model is perfect.
%
   uk = zeros(3,1);
   vk = zeros(3,1);
%
%  Initialize quantities that will be needed to seed the main loop 
%  that processes one measurement sample time per iteration.
%  These quantities will get updated once per iteration of
%  the loop.
%
   tkp1 = t0;
   xkp1 = x0;
   if i1stdrv == 1
      F_kp1_0 = ????;
   end
   irowvechbatch = (1:3)';
%
%  Cycle through all of the measurments, using 
%  
   for kp1 = 1:Nmeas
      tk = tkp1;
      xk = xkp1;
      tkp1 = tmeashist(kp1,1);
      deltk = tkp1 - tk;
      nRKk = ceil(deltk/deltRKmax);
      [????,F_kp1_k] = ...
             c2dnonlinear(xk,uk,vk,tk,tkp1,nRKk,fscriptname,i1stdrv);
      [hkp1,Hkp1] = hjmissile3dnl(tkp1,????,i1stdrv);
      hbatch(irowvechbatch,1) = ????;
% 
      if i1stdrv == 1
         F_k_0 = F_kp1_0;
         F_kp1_0 = ????;
         Hbatch(irowvechbatch,:) = ????;
      end
%         
      irowvechbatch = irowvechbatch + 3;
   end